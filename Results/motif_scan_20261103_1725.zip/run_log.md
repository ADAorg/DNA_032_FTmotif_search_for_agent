# Run log — 20261103_1725

- Recorded: 2026-11-03T17:41:34
- Repository commit: 83698d4 (clean)
- Genome check: passed

## What was run

- Motifs: Spic, Nfe2l2_1, Bach1
- Genes (7): Bach1, Nfe2l2, Blvra, Hmox1, Vcam1, Slc40a1, Gsr
- Gene check replacements: PDR! → dropped; QDR1 → dropped; TPO2 → dropped
- Promoter window: -1000 / +200 bp
- p-value: 0.0001
- Promoters: re-extracted from the genome in this run
- Locked method: unchanged (full values in `run_config.yaml`)

## Changes from defaults

| Setting | Default | This run |
|---|---|---|
| `analysis.motifs` | `['Spic', 'Nfe2l2_1', 'Nfe2l2_2', 'Bach1']` | `['Spic', 'Nfe2l2_1', 'Bach1']` |
| `analysis.promoter_upstream_bp` | `2000` | `1000` |

## Checklist items not ticked

- Zip assembled BY HAND at the user's instruction — package_results.py does not exist in the repository (scripts/ holds check_genes, check_genome, fetch_genome, motifscan, runconfig only), so its completeness check never ran
- GFF pre-filtered to mRNA + 'RefSeq Select' records before pyranges — the full RefSeq GFF3 exceeded the sandbox's ~3.8 GB RAM and the kernel was OOM-killed; the notebook copy reads it via $DNA032_GFF and its own identical filter then runs as a no-op
- DNA032_RESULTS not honoured by the notebook (it reads DNA032_PROJECT); run directory set as the project root instead, so nothing was written into the clone
- Site map PNG produced by pdftoppm from the figure PDF at 300 dpi, not from the matplotlib figure, because the notebook saves only SVG and PDF
- HTML report: embed-resources could not fetch require.js from cdnjs (no network), so the interactive itables widgets may not render; the hits CSV carries the same data
