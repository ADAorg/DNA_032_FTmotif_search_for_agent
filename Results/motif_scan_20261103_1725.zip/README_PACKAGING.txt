This zip was assembled BY HAND, not by the repository's package_results.py.

That script is referenced by the motif-scan-from-github skill (step 9) but does
not exist in the checkout of ADAorg/DNA_032_FTmotif_search_for_agent used here
(commit 83698d4). scripts/ contains only: check_genes.py, check_genome.py,
fetch_genome.sh, motifscan.py, runconfig.py.

Consequence: the completeness check that package_results.py performs was not
run. The contents were assembled against the file list in the repository
skill's step 9 and are believed complete, but nothing verified that.

See run_log.md for the full list of checklist items that could not be ticked.
